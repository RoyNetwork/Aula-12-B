dic = {"Salgado": 4.50,
       "Lanche": 6.50,
       "Suco": 3.00,
       "Refrigerante": 3.50,
       "Doce": 1.00}
print(dic)

