

#-------------------------------------------------------- ---------     Dicionarios 

D = {"arroz": 17.30,"feijão": 12.50,"carne": 23.90,"alface": 3.40}
print(D)

D["carne"] = 25.0
D["tomate"] = 8.80
print(D)