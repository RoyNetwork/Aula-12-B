#------------------------------------------------
#Working com dicionarios





classe = {"Ana": 4.5,
          "Beatriz": 6.5,
          "Geraldo": 1.0,
          "José": 10.0,
          "Maria": 9.5}
notas = classe.values()
média = sum(notas)/5
print("A média da classe é ",média)