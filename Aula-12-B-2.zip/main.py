

#Praticando com listas
#BeeGess--------------------------------------------#GeesBee


T = (10,20,30,40,50)
a,b,c,d,e = T
print("a =",a,"b =",b)

print("d + e =",d+e)

